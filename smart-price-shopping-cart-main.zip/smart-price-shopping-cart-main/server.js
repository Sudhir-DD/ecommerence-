const path = require('path');
const express = require('express');
const cookieParser = require('cookie-parser');

require('./db/database');
require('./db/seed')();

const { attachUser } = require('./middleware/auth');

const pagesRouter = require('./routes/pages');
const authRouter = require('./routes/auth');
const cartRouter = require('./routes/cart');
const ordersRouter = require('./routes/orders');
const priceAlertsRouter = require('./routes/priceAlerts');
const productsRouter = require('./routes/products');

const priceAlerts = require('./models/priceAlerts');
const sms = require('./services/sms');
const priceSimulator = require('./services/priceSimulator');

const app = express();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

app.use('/images', express.static(path.join(__dirname, 'images')));
app.use('/public', express.static(path.join(__dirname, 'public')));
app.use(express.static(__dirname, { index: false }));

app.use(attachUser);

app.use('/api/auth', authRouter);
app.use('/api/cart', cartRouter);
app.use('/api/price-alerts', priceAlertsRouter);
app.use('/api/products', productsRouter);
app.use('/api', ordersRouter);
app.use('/', pagesRouter);

app.use((req, res) => {
    res.status(404).render('404', { path: req.originalUrl });
});

app.use((err, req, res, next) => {
    console.error(err);
    res.status(500).json({ error: 'Something went wrong.' });
});

async function checkPriceAlerts() {
    const due = priceAlerts.findDueForNotification();

    for (const alert of due) {
        await sms.sendPriceAlert(alert.mobile, alert.name, alert.current_price);
        priceAlerts.markNotified(alert.id);
    }
}

const PRICE_ALERT_CHECK_INTERVAL_MS = 60 * 1000;
setInterval(() => {
    checkPriceAlerts().catch((err) => console.error('Price alert check failed:', err));
}, PRICE_ALERT_CHECK_INTERVAL_MS);

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log(`Shopping cart app listening on http://localhost:${PORT}`);
    checkPriceAlerts().catch((err) => console.error('Price alert check failed:', err));

    priceSimulator.start({
        onChange: () => checkPriceAlerts().catch((err) => console.error('Price alert check failed:', err))
    });
});
