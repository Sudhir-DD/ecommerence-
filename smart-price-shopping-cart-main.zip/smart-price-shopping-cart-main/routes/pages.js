const express = require('express');

const products = require('../models/products');
const cartModel = require('../models/cart');
const ordersModel = require('../models/orders');
const priceAlertsModel = require('../models/priceAlerts');
const insights = require('../services/insights');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

const CATEGORY_CARDS = [
    { slug: 'mobiles', label: 'Mobiles', emoji: '📱', thumb: '/mobile.png' },
    { slug: 'watches', label: 'Watches', emoji: '⌚', thumb: '/watches.png' },
    { slug: 'laptops', label: 'Laptops', emoji: '💻', thumb: '/laptop.png' },
    { slug: 'shoes', label: 'Shoes', emoji: '👟', thumb: '/shoes.png' },
    { slug: 'clothes', label: 'Clothes', emoji: '👕', thumb: '/clothes.png' },
    { slug: 'electronics', label: 'Electronics', emoji: '🔌', thumb: '/electronics.png' }
];

const CATEGORY_META = Object.fromEntries(
    CATEGORY_CARDS.map((c) => [c.slug, c])
);

router.get('/', (req, res) => {
    const drops = products
        .findAll()
        .map((p) => ({ ...p, ...insights.summary(p), meta: CATEGORY_META[p.category] }))
        .filter((p) => p.change30Pct <= -0.5)
        .sort((a, b) => a.change30Pct - b.change30Pct)
        .slice(0, 4);

    res.render('index', { categories: CATEGORY_CARDS, drops });
});

router.get('/product/:id', (req, res) => {
    const product = products.findById(Number(req.params.id));

    if (!product) {
        return res.status(404).render('404', { path: req.originalUrl });
    }

    res.render('product', { product, meta: CATEGORY_META[product.category] });
});

router.get('/category/:slug', (req, res) => {
    const { slug } = req.params;

    if (!products.isValidCategory(slug)) {
        return res.status(404).render('404', { path: req.originalUrl });
    }

    const items = products.findByCategory(slug).map((p) => ({ ...p, ...insights.summary(p) }));
    const meta = CATEGORY_META[slug];
    const nextSlug = products.nextCategory(slug);

    res.render('category', {
        slug,
        meta,
        products: items,
        nextSlug,
        nextMeta: CATEGORY_META[nextSlug]
    });
});

router.get('/login', (req, res) => {
    if (req.user) {
        return res.redirect('/');
    }

    res.render('login', { next: req.query.next || '/' });
});

router.get('/signup', (req, res) => {
    if (req.user) {
        return res.redirect('/');
    }

    res.render('signup');
});

router.get('/cart', requireAuth, (req, res) => {
    const items = cartModel.getItems(req.user.id);
    const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0);

    res.render('cart', { items, total });
});

router.get('/orders', requireAuth, (req, res) => {
    const orders = ordersModel.getOrdersForUser(req.user.id);

    res.render('orders', { orders });
});

router.get('/price-alerts', requireAuth, (req, res) => {
    const alerts = insights.withEta(priceAlertsModel.listForUser(req.user.id));
    const newlyReachedCount = priceAlertsModel.countUnseen(req.user.id);

    priceAlertsModel.acknowledgeReached(req.user.id);

    res.render('price-alerts', { alerts, newlyReachedCount });
});

module.exports = router;
