const db = require('../db/database');
const priceHistory = require('./priceHistory');

const CATEGORIES = ['mobiles', 'watches', 'laptops', 'shoes', 'clothes', 'electronics'];

function isValidCategory(slug) {
    return CATEGORIES.includes(slug);
}

function nextCategory(slug) {
    const index = CATEGORIES.indexOf(slug);
    return CATEGORIES[(index + 1) % CATEGORIES.length];
}

function findByCategory(category) {
    return db
        .prepare('SELECT * FROM products WHERE category = ? ORDER BY sort_order ASC')
        .all(category);
}

function findAll() {
    return db.prepare('SELECT * FROM products ORDER BY id ASC').all();
}

function findById(id) {
    return db.prepare('SELECT * FROM products WHERE id = ?').get(id);
}

// Changing a price always goes through here so the history stays complete.
function setPrice(id, price) {
    db.exec('BEGIN');

    try {
        db.prepare('UPDATE products SET price = ? WHERE id = ?').run(price, id);
        priceHistory.record(id, price);
        db.exec('COMMIT');
    } catch (err) {
        db.exec('ROLLBACK');
        throw err;
    }
}

module.exports = {
    CATEGORIES,
    isValidCategory,
    nextCategory,
    findByCategory,
    findAll,
    findById,
    setPrice
};
